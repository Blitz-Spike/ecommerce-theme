============================================================

Official website: https://www.zooextension.com
HelpDesk system: https://support.zooextension.com


============================================================


CHANGE LOG

## Version 2.0.0 Release Aug 16, 2019

`IMPORTANT:` The martify version 2.0.0 is completely rewritten from the ground up, so things will look a bit different than they do on your current site. We’re really sorry if the upgrade gives you problems, but we really think you will love the new martify. 

You're required to install the new version.


- New [Mega Menu Builder](https://doc.zooextension.com/shopify/mega-menu)
- Add new homepages 
- Improve UI/UX for All [Sections](https://doc.zooextension.com/shopify/martify/#/sections)
- New Grid Builder which allow you easy to create your own homepage
- Improve [Option/Variant Design](https://doc.zooextension.com/shopify/martify/#/theme-settings?id=optionvariant-design)
- Improve Canvas Cart
- Add a lot of [marketing tools to Boost up your sales](https://doc.zooextension.com/shopify/martify/#/theme-settings?id=product-item) without any monthly fees.
- Page load improvements: 53 Mobile / 96 desktop at Google Page Speed
- Page load improvements: PageSpeed Score A 93%  / Yslow Score D 61% at GTMetric
- And much more...


## Version 1.0.0 Release Jan 15, 2018

! Initial Release