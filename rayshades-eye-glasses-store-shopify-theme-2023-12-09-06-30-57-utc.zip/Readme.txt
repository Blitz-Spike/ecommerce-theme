Within the main folder [themeforest-rayshades-shopify-theme.zip] there will be following folder and files.

Documentation
Readme.txt
Log.txt
rayshades.zip

-------------------------------------------------------------------
https://themessupport.com/wedesigntech/shopify/rayshades/


Kindly refer our documentation for installing the theme and doing customization. 
If you need any assistance, plz contact us through support@wedesignthemes.com


Thank You.











